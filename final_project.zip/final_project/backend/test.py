# user_request = "Contract Benefit:\n•\tContractID: 7001\n•\tContractBeniftID: 7001-222\n•\tContractDetails:Preventative Care\n•\tContractBeniftID: 7001-223\n•\tContractDetails: Dental\n\n将上面的数据插入到Managercontract这个表里"
# print(user_request)

# sql_query = '\'7\''
#
# # 去掉所有的反斜杠
# cleaned_query = sql_query.replace('\\', '')
#
# print(cleaned_query)

user_request = "Account Information:\n•\tAccountID: 1001\n•\tAccountName: Apple \n•\tCompany: Apple Inc.\n\nInsert the above data into the 'Account' table."
print(user_request)


# data = [
#     {"AccountID": 1001, "AccountName": "Apple", "Company": "Apple Inc."},
#     {"AccountID": 1002, "AccountName": "google", "Company": "google Inc."},
#     {"AccountID": 1003, "AccountName": "Apple", "Company": "Apple Inc."}
# ]
#
# # 确定所有可能的键
#
#
#
# # 定义一个函数计算每个字段的最大宽度
# def calculate_widths(data, keys):
#     widths = {}
#     for key in keys:
#         key_width = len(key)
#         max_value_width = max(len(str(item.get(key, ''))) for item in data)
#         widths[key] = max(key_width, max_value_width)
#     return widths
#
#
# # 生成表格字符串
# def generate_table_string(data, keys):
#     widths = calculate_widths(data, keys)
#     headers = [' '.join(key.ljust(widths[key]) for key in keys)]
#     lines = [' '.join('-' * widths[key] for key in keys)]
#
#     rows = [headers, lines]
#     for item in data:
#         row = [' '.join(str(item.get(key, '')).ljust(widths[key]) for key in keys)]
#         rows.append(row)
#         rows.append(lines)
#
#     return '\n'.join('| '.join(row) for row in rows)
#
# def table(data):
#     all_keys = {key for item in data for key in item.keys()}
#     table_string = generate_table_string(data, all_keys)
#     return table_string
#
# print(table(data))
#
#
#
# #
# # SessionLocal = sessionmaker(bind=engine)
#
# # # 定义一个函数计算每个字段的最大宽度
# # def calculate_widths(data, keys):
# #     widths = {}
# #     for key in keys:
# #         key_width = len(key)
# #         max_value_width = max(len(str(item.get(key, ''))) for item in data)
# #         widths[key] = max(key_width, max_value_width)
# #     return widths
# #
# #
# # # 生成表格字符串
# # def generate_table_string(data, keys):
# #     widths = calculate_widths(data, keys)
# #     headers = [' '.join(key.ljust(widths[key]) for key in keys)]
# #     lines = [' '.join('-' * widths[key] for key in keys)]
# #
# #     rows = [headers, lines]
# #     for item in data:
# #         row = [' '.join(str(item.get(key, '')).ljust(widths[key]) for key in keys)]
# #         rows.append(row)
# #         rows.append(lines)
# #
# #     return '\n'.join('| '.join(row) for row in rows)
# #
# # def table(data):
# #     all_keys = {key for item in data for key in item.keys()}
# #     table_string = generate_table_string(data, all_keys)
# #     return table_string
#
# # import json
# #
# # @app.post("/api/module2/")
# # async def execute_sql(request: Request):
# #     data = await request.json()
# #     raw_sql = data.get("description")
# #
# #     # if not raw_sql:
# #     #     raise HTTPException(status_code=400, detail="SQL statement not provided")
# #
# #     try:
# #         # Execute the SQL command
# #         with engine.connect() as connection:
# #             result = connection.execute(text(raw_sql))
# #             if result.returns_rows:
# #                 return result.fetchall()
# #                 # rows = result.fetchall()
# #                 # rows_dict = [dict(row) for row in rows]
# #                 # json_string =  json.loads(json.dumps(rows_dict))
# #                 # return table(json_string)
# #             # json.dumps(result.fetchall())
# #             # 对于其他操作, 我们返回操作成功
# #             return {"status": "success"}
# #
# #             # return {"data": [dict(row) for row in result]}
# #     except SQLAlchemyError as e:
# #         raise HTTPException(status_code=500, detail=str(e))