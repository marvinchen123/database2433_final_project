import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import sklearn

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler,PolynomialFeatures
from sklearn.linear_model import LinearRegression,Ridge,Lasso,ElasticNet
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.linear_model import RidgeCV, LassoCV, ElasticNetCV

data = {
    'CustomerSSN': '444444444',
    'Diabetes': 'No',
    'BloodPressureProblems': 'No',
    'AnyTransplants': 'No',
    'AnyChronicDiseases': 'No',
    'Height': '170',
    'Weight': '50',
    'KnownAllergies': 'None',
    'HistoryOfCancerInFamily': 'No',
    'NumberOfMajorSurgeries': '1',
    'DiabetesPrediction': 'Low Risk',
    'PremiumPrice': 11606
}


# 定义转换规则
def convert_data(data):

    DiabetesPrediction = {'Low Risk': 0, 'Medium Risk': 1, 'High Risk': 2}

    new_data = {}

    # 处理文本到数字的转换
    for key, value in data.items():
        if value == 'No':
            new_data[key] = 0
        elif value == 'Yes':
            new_data[key] = 1
        elif key == 'Height' or key == 'Weight' or key == 'NumberOfMajorSurgeries':
            new_data[key] = int(value)
        elif key == 'DiabetesPrediction':
            new_data['Diabetes'] = DiabetesPrediction[value]
        elif key == 'CustomerSSN' or key == 'PremiumPrice' or key == 'Diabetes':
            continue
        else:
            new_data[key] = value

    # 处理已知的特殊字段
    if new_data.get('KnownAllergies') == 'None':
        new_data['KnownAllergies'] = 0
    else:
        new_data['KnownAllergies'] = 1

    # 假设你想为数据添加Age字段，这里我使用一个随机值作为示例
    # 你可以根据实际需求修改
    new_data['Age'] = 30  # 示例值，可以根据需要更改

    return new_data


x_predict = convert_data(data)

data = pd.read_csv('Medicalpremium.csv')

cols = [col for col in data.columns if col != 'PremiumPrice']
X = data[cols]
y = data['PremiumPrice']
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2, random_state=0)



Input=[ ('polynomial', PolynomialFeatures(include_bias=False,degree=2)),('ss',StandardScaler() ), ('model',Ridge(alpha=1))]
pipe = Pipeline(Input)
param_grid = {
    "polynomial__degree": [2],
    "model__alpha":[1]
}
search = GridSearchCV(pipe, param_grid, n_jobs=2)
search.fit(X_train, y_train)
best = search.best_estimator_
# print("best_score_: ",search.best_score_)
# print("best_params_: ",search.best_params_)


x_predict = pd.DataFrame([x_predict])
cols = ['Age', 'Diabetes', 'BloodPressureProblems', 'AnyTransplants', 'AnyChronicDiseases', 'Height', 'Weight', 'KnownAllergies', 'HistoryOfCancerInFamily', 'NumberOfMajorSurgeries']
x_predict = x_predict[cols]

y_pred = int(best.predict(x_predict))


print(y_pred)