import os
import openai

openai.api_key = ""


def get_sql_module3(user_request):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {
                "role": "system",
                "content": "Given the following SQL tables, your job is to write CRUD given a user’s request. Only output pure SQL statements each time; no other hints allowed. \n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`account` (\n  `AccountID` INT NOT NULL,\n  `AccountName` VARCHAR(255) NULL DEFAULT NULL,\n  `Company` VARCHAR(45) NULL DEFAULT NULL,\n  PRIMARY KEY (`AccountID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`accountadmin` (\n  `AccountAdminID` INT NOT NULL,\n  `AccountID` INT NOT NULL,\n  `AdminFirstName` VARCHAR(255) NOT NULL,\n  `AdminMiddleName` VARCHAR(45) NULL DEFAULT NULL,\n  `AdminLastName` VARCHAR(45) NULL DEFAULT NULL,\n  PRIMARY KEY (`AccountAdminID`),\n  INDEX `AccountID` (`AccountID` ASC) VISIBLE,\n  CONSTRAINT `accountadmin_ibfk_1`\n    FOREIGN KEY (`AccountID`)\n    REFERENCES `dmsproject`.`account` (`AccountID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`accountalias` (\n  `AccountAliasID` INT NOT NULL,\n  `AccountID` INT NOT NULL,\n  `AliasName` VARCHAR(255) NULL DEFAULT NULL,\n  PRIMARY KEY (`AccountAliasID`),\n  INDEX `AccountID` (`AccountID` ASC) VISIBLE,\n  CONSTRAINT `accountalias_ibfk_1`\n    FOREIGN KEY (`AccountID`)\n    REFERENCES `dmsproject`.`account` (`AccountID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`accountmember` (\n  `AccountMemberID` INT NOT NULL,\n  `AccountID` INT NOT NULL,\n  `MemberFirstName` VARCHAR(255) NOT NULL,\n  `MemberMiddleName` VARCHAR(45) NULL DEFAULT NULL,\n  PRIMARY KEY (`AccountMemberID`),\n  INDEX `AccountID` (`AccountID` ASC) VISIBLE,\n  CONSTRAINT `accountmember_ibfk_1`\n    FOREIGN KEY (`AccountID`)\n    REFERENCES `dmsproject`.`account` (`AccountID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`associate` (\n  `AssociateSSN` INT NOT NULL,\n  `AssociateFirstName` VARCHAR(255) NULL DEFAULT NULL,\n  `AssociateMiddleName` VARCHAR(45) NULL DEFAULT NULL,\n  `AssociateLastName` VARCHAR(45) NULL DEFAULT NULL,\n  `AssociatePhone` INT NULL DEFAULT NULL,\n  PRIMARY KEY (`AssociateSSN`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`billingaccount` (\n  `BillingAccountID` INT NOT NULL,\n  `AccountID` INT NOT NULL,\n  `BillingAddress` VARCHAR(255) NULL DEFAULT NULL,\n  PRIMARY KEY (`BillingAccountID`),\n  INDEX `AccountID` (`AccountID` ASC) VISIBLE,\n  CONSTRAINT `billingaccount_ibfk_1`\n    FOREIGN KEY (`AccountID`)\n    REFERENCES `dmsproject`.`account` (`AccountID`))\n\n\n\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`managercontract` (\n  `ManagerContractID` INT NOT NULL,\n  `AccountID` INT NOT NULL,\n  `AssociateSSN` INT NOT NULL,\n  `ContractDetails` VARCHAR(255) NULL DEFAULT NULL,\n  `ManagerContractStartDate` DATE NULL DEFAULT NULL,\n  `ManagerContractEndDate` DATE NULL DEFAULT NULL,\n  `Duration` INT NULL DEFAULT NULL,\n  PRIMARY KEY (`ManagerContractID`),\n  INDEX `AccountID` (`AccountID` ASC) VISIBLE,\n  INDEX `AssociateSSN` (`AssociateSSN` ASC) VISIBLE,\n  CONSTRAINT `managercontract_ibfk_1`\n    FOREIGN KEY (`AccountID`)\n    REFERENCES `dmsproject`.`account` (`AccountID`),\n  CONSTRAINT `managercontract_ibfk_2`\n    FOREIGN KEY (`AssociateSSN`)\n    REFERENCES `dmsproject`.`associate` (`AssociateSSN`))\n\n"
            },
            {
                "role": "user",
                "content": user_request
            },

        ],
        temperature=0,
        max_tokens=1024,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0
    )
    return response.choices[0].message.content


# user_request = "Account Information:\n•\tAccountID: 1001\n•\tAccountName: Apple \n•\tCompany: Apple Inc.\n\nInsert the above data into the 'Account' table."
user_request = "Please check the information in the account table"


sql_sentence = get_sql_module3(user_request)
print(sql_sentence)