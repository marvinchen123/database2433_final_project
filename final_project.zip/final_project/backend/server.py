import pandas as pd
import csv
from sklearn.preprocessing import QuantileTransformer
from imblearn.over_sampling import RandomOverSampler
from sklearn.ensemble import RandomForestClassifier
from sqlalchemy.exc import SQLAlchemyError
import openai
from sqlalchemy import create_engine, Column, Integer, String, DECIMAL
from sqlalchemy.ext.declarative import declarative_base
from fastapi import FastAPI, HTTPException
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from fastapi import FastAPI, Request
from fastapi.responses import Response, HTMLResponse
from fastapi.staticfiles import StaticFiles
import uvicorn
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler,PolynomialFeatures
from sklearn.linear_model import LinearRegression,Ridge,Lasso,ElasticNet
from sklearn.pipeline import Pipeline




# 定义转换规则
def convert_data(data):

    DiabetesPrediction = {'Low Risk': 0, 'Medium Risk': 1, 'High Risk': 2}

    new_data = {}

    # 处理文本到数字的转换
    for key, value in data.items():
        if value == 'No':
            new_data[key] = 0
        elif value == 'Yes':
            new_data[key] = 1
        elif key == 'Height' or key == 'Weight' or key == 'NumberOfMajorSurgeries':
            new_data[key] = int(value)
        elif key == 'DiabetesPrediction':
            new_data['Diabetes'] = DiabetesPrediction[value]
        elif key == 'CustomerSSN' or key == 'PremiumPrice' or key == 'Diabetes':
            continue
        else:
            new_data[key] = value

    # 处理已知的特殊字段
    if new_data.get('KnownAllergies') == 'None':
        new_data['KnownAllergies'] = 0
    else:
        new_data['KnownAllergies'] = 1

    # 假设你想为数据添加Age字段，这里我使用一个随机值作为示例
    # 你可以根据实际需求修改
    new_data['Age'] = 30  # 示例值，可以根据需要更改

    return new_data




def predict_premium(data):
    x_predict = convert_data(data)

    data = pd.read_csv('Medicalpremium.csv')

    cols = [col for col in data.columns if col != 'PremiumPrice']
    X = data[cols]
    y = data['PremiumPrice']
    X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2, random_state=0)


    Input=[ ('polynomial', PolynomialFeatures(include_bias=False,degree=2)),('ss',StandardScaler() ), ('model',Ridge(alpha=1))]
    pipe = Pipeline(Input)
    param_grid = {
        "polynomial__degree": [2],
        "model__alpha":[1]
    }
    search = GridSearchCV(pipe, param_grid, n_jobs=2)
    search.fit(X_train, y_train)
    best = search.best_estimator_
    # print("best_score_: ",search.best_score_)
    # print("best_params_: ",search.best_params_)


    x_predict = pd.DataFrame([x_predict])
    cols = ['Age', 'Diabetes', 'BloodPressureProblems', 'AnyTransplants', 'AnyChronicDiseases', 'Height', 'Weight', 'KnownAllergies', 'HistoryOfCancerInFamily', 'NumberOfMajorSurgeries']
    x_predict = x_predict[cols]

    y_pred = int(best.predict(x_predict))

    return y_pred




def transform_income(income):
    income = int(income)
    if income < 50000:
        return 1
    elif 50000 <= income < 100000:
        return 2
    elif 100000 <= income < 150000:
        return 3
    else:
        return 4


def transform_data(data):
    mapping = {
        'DiabetesPrediction': {'Low Risk': 0, 'Medium Risk': 1, 'High Risk': 2},
        'HighBP': {'No': 0, 'Yes': 1},
        'HighChol': {'No': 0, 'Yes': 1},
        'CholCheck': {'No': 0, 'Yes': 1},
        'Smoker': {'No': 0, 'Yes': 1},
        'Stroke': {'No': 0, 'Yes': 1},
        'HeartDiseaseorAttack': {'No': 0, 'Yes': 1},
        'PhysActivity': {'Regular': 0, 'Seldom': 1},
        'Fruits': {'Daily': 0, 'Rarely': 1},
        'Veggies': {'Daily': 0, 'Rarely': 1},
        'HvyAlcoholConsump': {'No': 0, 'Yes': 1},
        'AnyHealthcare': {'No': 0, 'Yes': 1},
        'NoDocbcCost': {'No': 0, 'Yes': 1},
        'GenHlth': {'Poor': 1, 'Average': 3, 'Good': 5},
        'MentHlth': {'Poor': 1, 'Average': 3, 'Good': 5},
        'PhysHlth': {'Poor': 1, 'Average': 3, 'Good': 5},
        'DiffWalk': {'No': 0, 'Yes': 1},
        'Sex': {'Male': 0, 'Female': 1},
        'Education': {'High School': 2, 'Bachelor': 3, 'Master': 4, 'PhD': 5},
        # 'Income': {'<40000': 1, '40000-80000': 2, '80000-120000': 3, '>120000': 4}
    }



    transformed_data = {}
    for key, value in data.items():
        if key in mapping:
            transformed_data[key] = mapping[key].get(value, value)
        elif key == 'Income':
            transformed_data[key] = transform_income(value)
        else:
            transformed_data[key] = value

    return transformed_data

def predict_risk(data):
    age = 10


    data['age'] = age
    transformed_data = transform_data(data)

    ordered_keys = ['DiabetesPrediction', 'HighBP', 'HighChol', 'CholCheck', 'BMI', 'Smoker', 'Stroke',
                    'HeartDiseaseorAttack', 'PhysActivity', 'Fruits', 'Veggies', 'HvyAlcoholConsump', 'AnyHealthcare',
                    'NoDocbcCost', 'GenHlth', 'MentHlth', 'PhysHlth', 'DiffWalk', 'Sex', 'age', 'Education', 'Income']
    data_list = [transformed_data[key] for key in ordered_keys]

    with open('diabetes_012_health_indicators_BRFSS2015.csv', 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(data_list)

    # 读取数据
    df = pd.read_csv('diabetes_012_health_indicators_BRFSS2015.csv')

    # 更改某列名称
    df.rename(columns={'Diabetes_012': 'Diabetes_binary'}, inplace=True)

    # 创建新的特征：在过去30天内没有生病并且感觉非常好或者很好的人
    df['PerfectHlth'] = (df['PhysHlth'] == 0.0) & (df['GenHlth'] < 3.0)
    df['PerfectHlth'] = df['PerfectHlth'].astype(int)

    # 创建新的特征：没有心脏疾病或高血压的人
    df['NoHrtIssue'] = (df['HighBP'] == 0.0) & (df['HighChol'] == 0.0) & (df['HeartDiseaseorAttack'] == 0.0)
    df['NoHrtIssue'] = df['NoHrtIssue'].astype(int)

    # 创建新的特征：健康状况不太好的人和健康状况好于普通的人
    df['hlthNotGood'] = df['GenHlth'] > 3
    df['HlthAboveGood'] = df['GenHlth'] < 3
    df['hlthNotGood'] = df['hlthNotGood'].astype(int)
    df['HlthAboveGood'] = df['HlthAboveGood'].astype(int)

    # 创建新的特征：有高血压和心脏疾病的人，以及年纪大且收入低的人
    df['hbp&HA'] = (df['HeartDiseaseorAttack'] == 1.0) & (df['HighBP'] == 1.0)
    df['hbp&HA'] = df['hbp&HA'].astype(int)
    df['older&poor'] = (df['Age'] > 5.0) & (df['Income'] < 5)
    df['older&poor'] = df['older&poor'].astype(int)

    # 根据相关性删除不相关的列
    df2 = df.drop(['Fruits', 'Veggies', 'AnyHealthcare', 'NoDocbcCost', 'Income',
                   'Education', 'CholCheck'], axis=1)
    df3 = df2.copy()

    # 使用标准化方法标准化部分特征
    sc = StandardScaler()
    df3[['BMI']] = sc.fit_transform(df3[['BMI']])
    df3[['Age']] = sc.fit_transform(df3[['Age']])
    df3[['PhysHlth']] = sc.fit_transform(df3[['PhysHlth']])
    df3[['MentHlth']] = sc.fit_transform(df3[['MentHlth']])

    # 使用QuantileTransformer进一步转换特征
    QT = QuantileTransformer(n_quantiles=500, output_distribution='normal')
    df3[['BMI']] = QT.fit_transform(df3[['BMI']])
    df3[['Age']] = QT.fit_transform(df3[['Age']])
    df3[['PhysHlth']] = QT.fit_transform(df3[['PhysHlth']])
    df3[['MentHlth']] = QT.fit_transform(df3[['MentHlth']])

    # 定义特征和目标变量
    X = df3.drop('Diabetes_binary', axis=1)
    y = df3['Diabetes_binary']

    predict_X = X[-1:]
    X = X[:-1]
    y = y[:-1]

    # 使用过采样方法处理不平衡数据
    OverS = RandomOverSampler(random_state=99, sampling_strategy='not majority')
    X_over, y_over = OverS.fit_resample(X, y)

    # 数据切分为训练集和测试集
    X_over_train, X_over_test, y_over_train, y_over_test = train_test_split(X_over, y_over, test_size=0.2,
                                                                            random_state=99)

    # 使用最佳参数训练一个新的随机森林模型
    best_rfc = RandomForestClassifier(n_estimators=300, max_depth=20)
    best_rfc.fit(X_over_train, y_over_train)

    # 对测试集进行预测并计算各种评估指标
    y_pred = int(best_rfc.predict(predict_X))

    # 读取CSV文件的内容
    with open('diabetes_012_health_indicators_BRFSS2015.csv', 'r') as file:
        reader = csv.reader(file)
        rows = list(reader)

    # 更改最后一行的第一个元素
    if rows:
        rows[-1][0] = y_pred

    # 将修改后的内容写回CSV文件
    with open('diabetes_012_health_indicators_BRFSS2015.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(rows)

    reverse_diabetes_prediction_mapping = {0: 'Low Risk', 1: 'Medium Risk', 2: 'High Risk'}
    risk = reverse_diabetes_prediction_mapping[y_pred]
    return risk


# 创建FastAPI实例
app = FastAPI()

# 连接数据库
DATABASE_URL = ""
engine = create_engine(DATABASE_URL)

app = FastAPI()
app.mount("/frontend", StaticFiles(directory=r"C:\Users\czy\Desktop\final_project\frontend"), name="static")


@app.get("/")
async def index():

    response2 = Response('''

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" href="https://unpkg.com/element-ui/lib/theme-chalk/index.css" />
    <title>Insurance Management System</title>
    <style>
        #app {
            width: 1024px;
            margin: 0 auto;
        }

        .add-btn {
            margin-top: 20px;
            width: 100%;
        }

        .body {
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div id="app">
        <center>
            <h1>Insurance Management System</h1>
        </center>
        <div class="head">
            <a href=/frontend/ModuleOne.html><el-button type="primary" class="add-btn" plain>Module One: User Insurance Price Generation</el-button></a>
            <a href=/frontend/ModuleTwo.html><el-button type="primary" class="add-btn" plain>Module Two: Insurance Contract Information</el-button></a>
            <a href=/frontend/ModuleThree.html><el-button type="primary" class="add-btn" plain>Module Three: Company Registration Information</el-button></a>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
    <script src="https://unpkg.com/element-ui/lib/index.js"></script>
    <!-- 官网提供的 axios 在线地址 -->
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script>
        // var a='http://127.0.0.1:5555/s'
        new Vue({
            el: "#app",
            data: function () {
                return {};
            },

            methods: {},
        });
    </script>
</body>

</html>


    ''', media_type="text/html")

    return response2





Base = declarative_base()

class DiabetesRecord(Base):
    __tablename__ = 'diabetes'

    id = Column(Integer, primary_key=True)
    CustomerSSN = Column(Integer, nullable=False)
    DiabetesPrediction = Column(String(45))
    HighBP = Column(String(45))
    HighChol = Column(String(45))
    CholCheck = Column(String(45))
    BMI = Column(String(45))
    Smoker = Column(String(45))
    Stroke = Column(String(45))
    HeartDiseaseorAttack = Column(String(45))
    PhysActivity = Column(String(45))
    Fruits = Column(String(45))
    Veggies = Column(String(45))
    HvyAlcoholConsump = Column(String(45))
    AnyHealthcare = Column(String(45))
    NoDocbcCost = Column(String(45))
    GenHlth = Column(String(45))
    MentHlth = Column(String(45))
    PhysHlth = Column(String(45))
    DiffWalk = Column(String(45))
    Sex = Column(String(45))
    Education = Column(String(45))
    Income = Column(String(45))





# 创建数据库会话
Session = sessionmaker(bind=engine)


@app.post("/api/diabetes/add")
async def add_diabetes_record(request: Request):
    data = await request.json()

    result = predict_risk(data)
    data['DiabetesPrediction'] = result
    data.pop("age")
    new_record = DiabetesRecord(**data)

    session = Session()

    try:
        session.add(new_record)
        session.commit()
        return {"status": "success", "message": "Record added successfully", "data": result}
    except Exception as e:
        session.rollback()
        raise Exception(f"Failed to add record: {str(e)}")
    finally:
        session.close()




# 首先，定义Customer模型
class Customer(Base):
    __tablename__ = 'customer'

    CustomerSSN = Column(Integer, primary_key=True)
    CustomerFirstName = Column(String(255), nullable=False)
    CustomerMiddleName = Column(String(45))
    CustomerLastName = Column(String(45), nullable=False)
    CustomerAddress = Column(String(255))
    CustomerSalutation = Column(String(45))
    Gender = Column(String(1), nullable=False)
    CustomerDOB = Column(String(10), nullable=False)  # 此处我使用了String代替Date，确保前端传来的日期格式是'YYYY-MM-DD'
    CustomerMartial = Column(String(45))
    Age = Column(Integer)
    Height = Column(String(45))
    customercol = Column(String(45))



# 然后，创建一个POST路由处理函数
@app.post("/api/customer/add")
async def add_customer(request: Request):
    data = await request.json()

    # 转换日期格式
    if 'CustomerDOB' in data:
        data['CustomerDOB'] = data['CustomerDOB'][0:10]


    new_customer = Customer(**data)

    session = Session()
    try:
        session.add(new_customer)
        session.commit()
        return {"status": "success", "message": "Customer added successfully"}
    except Exception as e:
        session.rollback()
        raise Exception(f"Failed to add customer: {str(e)}")
    finally:
        session.close()



Base = declarative_base()

class PremiumRecord(Base):
    __tablename__ = 'premium'

    CustomerSSN = Column(Integer, primary_key=True)
    Diabetes = Column(String(45))
    BloodPressureProblems = Column(String(45))
    AnyTransplants = Column(String(45))
    AnyChronicDiseases = Column(String(45))
    Height = Column(String(45))
    Weight = Column(String(45))
    KnownAllergies = Column(String(45))
    HistoryOfCancerInFamily = Column(String(45))
    NumberOfMajorSurgeries = Column(Integer)
    DiabetesPrediction = Column(String(45))
    PremiumPrice = Column(DECIMAL(10,2))



# # Assuming the engine is already defined
# Session = sessionmaker(bind=engine)


@app.post("/api/premium/add")
async def add_premium_record(request: Request):
    data = await request.json()
    price = predict_premium(data)
    data['PremiumPrice'] = price
    new_record = PremiumRecord(**data)

    session = Session()

    try:
        session.add(new_record)
        session.commit()
        return {"status": "success", "message": "Record added successfully", "data": price}
    except Exception as e:
        session.rollback()
        raise Exception(f"Failed to add record: {str(e)}")
    finally:
        session.close()



openai.api_key = ""


def get_sql_module2(user_request):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {
                "role": "system",
                "content": "Given the following SQL tables, your job is to write CRUD given a user’s request. Only output pure SQL statements each time; no other hints allowed. Use the mysql version of sql statements. \n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`contract` (\n  `ContractID` INT NOT NULL,\n  `CustomerSSN` INT NOT NULL,\n  `ContractDetails` VARCHAR(255) NULL DEFAULT NULL,\n  PRIMARY KEY (`ContractID`),\n  INDEX `CustomerID` (`CustomerSSN` ASC) VISIBLE,\n  CONSTRAINT `contract_ibfk_1`\n    FOREIGN KEY (`CustomerSSN`)\n    REFERENCES `dmsproject`.`customer` (`CustomerSSN`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`contractbenefit` (\n  `ContractBenefitID` INT NOT NULL,\n  `ContractID` INT NULL DEFAULT NULL,\n  `BenefitDetails` VARCHAR(255) NULL DEFAULT NULL,\n  `ContractPremiumID` INT NULL DEFAULT NULL,\n  PRIMARY KEY (`ContractBenefitID`),\n  INDEX `ContractID` (`ContractID` ASC) VISIBLE,\n  CONSTRAINT `contractbenefit_ibfk_1`\n    FOREIGN KEY (`ContractID`)\n    REFERENCES `dmsproject`.`contract` (`ContractID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`customeraccountmember` (\n  `CustomerSSN` INT NOT NULL,\n  `AccountMemberID` INT NOT NULL,\n  `AccountStartDate` DATE NULL DEFAULT NULL,\n  `AccountEndDate` DATE NULL DEFAULT NULL,\n  `Comapany` VARCHAR(45) NULL DEFAULT NULL,\n  PRIMARY KEY (`CustomerSSN`, `AccountMemberID`),\n  INDEX `AccountMemberID` (`AccountMemberID` ASC) VISIBLE,\n  CONSTRAINT `customeraccountmember_ibfk_1`\n    FOREIGN KEY (`CustomerSSN`)\n    REFERENCES `dmsproject`.`customer` (`CustomerSSN`),\n  CONSTRAINT `customeraccountmember_ibfk_2`\n    FOREIGN KEY (`AccountMemberID`)\n    REFERENCES `dmsproject`.`accountmember` (`AccountMemberID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`customerassociate` (\n  `CustomerSSN` INT NOT NULL,\n  `AssociateSSN` INT NOT NULL,\n  `AssociateRole` VARCHAR(255) NULL DEFAULT NULL,\n  `Service_StartDate` DATE NULL DEFAULT NULL,\n  PRIMARY KEY (`CustomerSSN`, `AssociateSSN`),\n  INDEX `AssociateSSN` (`AssociateSSN` ASC) VISIBLE,\n  CONSTRAINT `customerassociate_ibfk_1`\n    FOREIGN KEY (`CustomerSSN`)\n    REFERENCES `dmsproject`.`customer` (`CustomerSSN`),\n  CONSTRAINT `customerassociate_ibfk_2`\n    FOREIGN KEY (`AssociateSSN`)\n    REFERENCES `dmsproject`.`associate` (`AssociateSSN`))\n"
            },
            {
                "role": "user",
                "content": user_request
            },

        ],
        temperature=0,
        max_tokens=1024,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0
    )

    print(response.choices[0].message.content)
    return response.choices[0].message.content



@app.post("/api/module2/")
async def execute_sql(request: Request):
    data = await request.json()
    user_request = data.get("description")

    sql_sentence = get_sql_module2(user_request)
    # sql_sentence = 'SELECT * FROM `dmsproject`.`contract`'
    try:
        # Execute the SQL command
        with engine.connect() as connection:
            result = connection.execute(text(sql_sentence))
            if result.returns_rows:
                return result.fetchall()
            # 对于其他操作, 我们返回操作成功
            return {"status": "success"}

    except SQLAlchemyError as e:
        raise HTTPException(status_code=500, detail=str(e))




def get_sql_module3(user_request):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {
                "role": "system",
                "content": "Given the following SQL tables, your job is to write CRUD given a user’s request. Only output pure SQL statements each time; no other hints allowed. \n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`account` (\n  `AccountID` INT NOT NULL,\n  `AccountName` VARCHAR(255) NULL DEFAULT NULL,\n  `Company` VARCHAR(45) NULL DEFAULT NULL,\n  PRIMARY KEY (`AccountID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`accountadmin` (\n  `AccountAdminID` INT NOT NULL,\n  `AccountID` INT NOT NULL,\n  `AdminFirstName` VARCHAR(255) NOT NULL,\n  `AdminMiddleName` VARCHAR(45) NULL DEFAULT NULL,\n  `AdminLastName` VARCHAR(45) NULL DEFAULT NULL,\n  PRIMARY KEY (`AccountAdminID`),\n  INDEX `AccountID` (`AccountID` ASC) VISIBLE,\n  CONSTRAINT `accountadmin_ibfk_1`\n    FOREIGN KEY (`AccountID`)\n    REFERENCES `dmsproject`.`account` (`AccountID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`accountalias` (\n  `AccountAliasID` INT NOT NULL,\n  `AccountID` INT NOT NULL,\n  `AliasName` VARCHAR(255) NULL DEFAULT NULL,\n  PRIMARY KEY (`AccountAliasID`),\n  INDEX `AccountID` (`AccountID` ASC) VISIBLE,\n  CONSTRAINT `accountalias_ibfk_1`\n    FOREIGN KEY (`AccountID`)\n    REFERENCES `dmsproject`.`account` (`AccountID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`accountmember` (\n  `AccountMemberID` INT NOT NULL,\n  `AccountID` INT NOT NULL,\n  `MemberFirstName` VARCHAR(255) NOT NULL,\n  `MemberMiddleName` VARCHAR(45) NULL DEFAULT NULL,\n  PRIMARY KEY (`AccountMemberID`),\n  INDEX `AccountID` (`AccountID` ASC) VISIBLE,\n  CONSTRAINT `accountmember_ibfk_1`\n    FOREIGN KEY (`AccountID`)\n    REFERENCES `dmsproject`.`account` (`AccountID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`associate` (\n  `AssociateSSN` INT NOT NULL,\n  `AssociateFirstName` VARCHAR(255) NULL DEFAULT NULL,\n  `AssociateMiddleName` VARCHAR(45) NULL DEFAULT NULL,\n  `AssociateLastName` VARCHAR(45) NULL DEFAULT NULL,\n  `AssociatePhone` INT NULL DEFAULT NULL,\n  PRIMARY KEY (`AssociateSSN`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`billingaccount` (\n  `BillingAccountID` INT NOT NULL,\n  `AccountID` INT NOT NULL,\n  `BillingAddress` VARCHAR(255) NULL DEFAULT NULL,\n  PRIMARY KEY (`BillingAccountID`),\n  INDEX `AccountID` (`AccountID` ASC) VISIBLE,\n  CONSTRAINT `billingaccount_ibfk_1`\n    FOREIGN KEY (`AccountID`)\n    REFERENCES `dmsproject`.`account` (`AccountID`))\n\n\n\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`managercontract` (\n  `ManagerContractID` INT NOT NULL,\n  `AccountID` INT NOT NULL,\n  `AssociateSSN` INT NOT NULL,\n  `ContractDetails` VARCHAR(255) NULL DEFAULT NULL,\n  `ManagerContractStartDate` DATE NULL DEFAULT NULL,\n  `ManagerContractEndDate` DATE NULL DEFAULT NULL,\n  `Duration` INT NULL DEFAULT NULL,\n  PRIMARY KEY (`ManagerContractID`),\n  INDEX `AccountID` (`AccountID` ASC) VISIBLE,\n  INDEX `AssociateSSN` (`AssociateSSN` ASC) VISIBLE,\n  CONSTRAINT `managercontract_ibfk_1`\n    FOREIGN KEY (`AccountID`)\n    REFERENCES `dmsproject`.`account` (`AccountID`),\n  CONSTRAINT `managercontract_ibfk_2`\n    FOREIGN KEY (`AssociateSSN`)\n    REFERENCES `dmsproject`.`associate` (`AssociateSSN`))\n\n"
            },
            {
                "role": "user",
                "content": user_request
            },

        ],
        temperature=0,
        max_tokens=1024,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0
    )
    return response.choices[0].message.content


@app.post("/api/module3/")
async def execute_sql(request: Request):
    data = await request.json()
    user_request = data.get("description")

    sql_sentence = get_sql_module3(user_request)
    # sql_sentence = 'SELECT * FROM `dmsproject`.`contract`'

    try:
        # Execute the SQL command
        with engine.connect() as connection:
            result = connection.execute(text(sql_sentence))
            if result.returns_rows:
                return result.fetchall()
            # 对于其他操作, 我们返回操作成功
            return {"status": "success"}

    except SQLAlchemyError as e:
        raise HTTPException(status_code=500, detail=str(e))




if __name__ == "__main__":
    uvicorn.run("server:app", host="127.0.0.1", port=5555)







