import pandas as pd
import csv
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import QuantileTransformer
from sklearn.preprocessing import StandardScaler,MinMaxScaler
from sklearn.preprocessing import LabelEncoder
from imblearn.over_sampling import RandomOverSampler
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import ConfusionMatrixDisplay
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score,classification_report,
                            ConfusionMatrixDisplay,precision_score,recall_score,
                            f1_score,roc_auc_score,roc_curve,balanced_accuracy_score,
                            confusion_matrix)




from fastapi import FastAPI, HTTPException
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from unittest import result
from fastapi import FastAPI, Request
from fastapi.responses import Response, HTMLResponse
from fastapi.staticfiles import StaticFiles
import uvicorn


from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler,PolynomialFeatures
from sklearn.linear_model import LinearRegression,Ridge,Lasso,ElasticNet
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.linear_model import RidgeCV, LassoCV, ElasticNetCV



# 定义转换规则
def convert_data(data):

    DiabetesPrediction = {'Low Risk': 0, 'Medium Risk': 1, 'High Risk': 2}

    new_data = {}

    # 处理文本到数字的转换
    for key, value in data.items():
        if value == 'No':
            new_data[key] = 0
        elif value == 'Yes':
            new_data[key] = 1
        elif key == 'Height' or key == 'Weight' or key == 'NumberOfMajorSurgeries':
            new_data[key] = int(value)
        elif key == 'DiabetesPrediction':
            new_data['Diabetes'] = DiabetesPrediction[value]
        elif key == 'CustomerSSN' or key == 'PremiumPrice' or key == 'Diabetes':
            continue
        else:
            new_data[key] = value

    # 处理已知的特殊字段
    if new_data.get('KnownAllergies') == 'None':
        new_data['KnownAllergies'] = 0
    else:
        new_data['KnownAllergies'] = 1

    # 假设你想为数据添加Age字段，这里我使用一个随机值作为示例
    # 你可以根据实际需求修改
    new_data['Age'] = 30  # 示例值，可以根据需要更改

    return new_data




def predict_premium(data):
    x_predict = convert_data(data)

    data = pd.read_csv('Medicalpremium.csv')

    cols = [col for col in data.columns if col != 'PremiumPrice']
    X = data[cols]
    y = data['PremiumPrice']
    X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2, random_state=0)


    Input=[ ('polynomial', PolynomialFeatures(include_bias=False,degree=2)),('ss',StandardScaler() ), ('model',Ridge(alpha=1))]
    pipe = Pipeline(Input)
    param_grid = {
        "polynomial__degree": [2],
        "model__alpha":[1]
    }
    search = GridSearchCV(pipe, param_grid, n_jobs=2)
    search.fit(X_train, y_train)
    best = search.best_estimator_
    # print("best_score_: ",search.best_score_)
    # print("best_params_: ",search.best_params_)


    x_predict = pd.DataFrame([x_predict])
    cols = ['Age', 'Diabetes', 'BloodPressureProblems', 'AnyTransplants', 'AnyChronicDiseases', 'Height', 'Weight', 'KnownAllergies', 'HistoryOfCancerInFamily', 'NumberOfMajorSurgeries']
    x_predict = x_predict[cols]

    y_pred = int(best.predict(x_predict))

    return y_pred




def transform_income(income):
    income = int(income)
    if income < 50000:
        return 1
    elif 50000 <= income < 100000:
        return 2
    elif 100000 <= income < 150000:
        return 3
    else:
        return 4


def transform_data(data):
    mapping = {
        'DiabetesPrediction': {'Low Risk': 0, 'Medium Risk': 1, 'High Risk': 2},
        'HighBP': {'No': 0, 'Yes': 1},
        'HighChol': {'No': 0, 'Yes': 1},
        'CholCheck': {'No': 0, 'Yes': 1},
        'Smoker': {'No': 0, 'Yes': 1},
        'Stroke': {'No': 0, 'Yes': 1},
        'HeartDiseaseorAttack': {'No': 0, 'Yes': 1},
        'PhysActivity': {'Regular': 0, 'Seldom': 1},
        'Fruits': {'Daily': 0, 'Rarely': 1},
        'Veggies': {'Daily': 0, 'Rarely': 1},
        'HvyAlcoholConsump': {'No': 0, 'Yes': 1},
        'AnyHealthcare': {'No': 0, 'Yes': 1},
        'NoDocbcCost': {'No': 0, 'Yes': 1},
        'GenHlth': {'Poor': 1, 'Average': 3, 'Good': 5},
        'MentHlth': {'Poor': 1, 'Average': 3, 'Good': 5},
        'PhysHlth': {'Poor': 1, 'Average': 3, 'Good': 5},
        'DiffWalk': {'No': 0, 'Yes': 1},
        'Sex': {'Male': 0, 'Female': 1},
        'Education': {'High School': 2, 'Bachelor': 3, 'Master': 4, 'PhD': 5},
        # 'Income': {'<40000': 1, '40000-80000': 2, '80000-120000': 3, '>120000': 4}
    }



    transformed_data = {}
    for key, value in data.items():
        if key in mapping:
            transformed_data[key] = mapping[key].get(value, value)
        elif key == 'Income':
            transformed_data[key] = transform_income(value)
        else:
            transformed_data[key] = value

    return transformed_data

def predict_risk(data):
    age = 10

    # data = {'CustomerSSN': '444444444', 'DiabetesPrediction': 'Low Risk', 'HighBP': 'No', 'HighChol': 'No',
    #         'CholCheck': 'Yes', 'BMI': '23', 'Smoker': 'No', 'Stroke': 'No', 'HeartDiseaseorAttack': 'No',
    #         'PhysActivity': 'Regular', 'Fruits': 'Daily', 'Veggies': 'Daily', 'HvyAlcoholConsump': 'No',
    #         'AnyHealthcare': 'Yes', 'NoDocbcCost': 'No', 'GenHlth': 'Good', 'MentHlth': 'Good', 'PhysHlth': 'Good',
    #         'DiffWalk': 'No', 'Sex': 'Male', 'Education': "Master", 'Income': '120000'}

    data['age'] = age
    transformed_data = transform_data(data)

    ordered_keys = ['DiabetesPrediction', 'HighBP', 'HighChol', 'CholCheck', 'BMI', 'Smoker', 'Stroke',
                    'HeartDiseaseorAttack', 'PhysActivity', 'Fruits', 'Veggies', 'HvyAlcoholConsump', 'AnyHealthcare',
                    'NoDocbcCost', 'GenHlth', 'MentHlth', 'PhysHlth', 'DiffWalk', 'Sex', 'age', 'Education', 'Income']
    data_list = [transformed_data[key] for key in ordered_keys]

    with open('diabetes_012_health_indicators_BRFSS2015.csv', 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(data_list)

    # 读取数据
    df = pd.read_csv('diabetes_012_health_indicators_BRFSS2015.csv')

    # 更改某列名称
    df.rename(columns={'Diabetes_012': 'Diabetes_binary'}, inplace=True)

    # 创建新的特征：在过去30天内没有生病并且感觉非常好或者很好的人
    df['PerfectHlth'] = (df['PhysHlth'] == 0.0) & (df['GenHlth'] < 3.0)
    df['PerfectHlth'] = df['PerfectHlth'].astype(int)

    # 创建新的特征：没有心脏疾病或高血压的人
    df['NoHrtIssue'] = (df['HighBP'] == 0.0) & (df['HighChol'] == 0.0) & (df['HeartDiseaseorAttack'] == 0.0)
    df['NoHrtIssue'] = df['NoHrtIssue'].astype(int)

    # 创建新的特征：健康状况不太好的人和健康状况好于普通的人
    df['hlthNotGood'] = df['GenHlth'] > 3
    df['HlthAboveGood'] = df['GenHlth'] < 3
    df['hlthNotGood'] = df['hlthNotGood'].astype(int)
    df['HlthAboveGood'] = df['HlthAboveGood'].astype(int)

    # 创建新的特征：有高血压和心脏疾病的人，以及年纪大且收入低的人
    df['hbp&HA'] = (df['HeartDiseaseorAttack'] == 1.0) & (df['HighBP'] == 1.0)
    df['hbp&HA'] = df['hbp&HA'].astype(int)
    df['older&poor'] = (df['Age'] > 5.0) & (df['Income'] < 5)
    df['older&poor'] = df['older&poor'].astype(int)

    # 根据相关性删除不相关的列
    df2 = df.drop(['Fruits', 'Veggies', 'AnyHealthcare', 'NoDocbcCost', 'Income',
                   'Education', 'CholCheck'], axis=1)
    df3 = df2.copy()

    # 使用标准化方法标准化部分特征
    sc = StandardScaler()
    df3[['BMI']] = sc.fit_transform(df3[['BMI']])
    df3[['Age']] = sc.fit_transform(df3[['Age']])
    df3[['PhysHlth']] = sc.fit_transform(df3[['PhysHlth']])
    df3[['MentHlth']] = sc.fit_transform(df3[['MentHlth']])

    # 使用QuantileTransformer进一步转换特征
    QT = QuantileTransformer(n_quantiles=500, output_distribution='normal')
    df3[['BMI']] = QT.fit_transform(df3[['BMI']])
    df3[['Age']] = QT.fit_transform(df3[['Age']])
    df3[['PhysHlth']] = QT.fit_transform(df3[['PhysHlth']])
    df3[['MentHlth']] = QT.fit_transform(df3[['MentHlth']])

    # 定义特征和目标变量
    X = df3.drop('Diabetes_binary', axis=1)
    y = df3['Diabetes_binary']

    predict_X = X[-1:]
    X = X[:-1]
    y = y[:-1]

    # 使用过采样方法处理不平衡数据
    OverS = RandomOverSampler(random_state=99, sampling_strategy='not majority')
    X_over, y_over = OverS.fit_resample(X, y)

    # 数据切分为训练集和测试集
    X_over_train, X_over_test, y_over_train, y_over_test = train_test_split(X_over, y_over, test_size=0.2,
                                                                            random_state=99)

    # 使用最佳参数训练一个新的随机森林模型
    best_rfc = RandomForestClassifier(n_estimators=300, max_depth=20)
    best_rfc.fit(X_over_train, y_over_train)

    # 对测试集进行预测并计算各种评估指标
    y_pred = int(best_rfc.predict(predict_X))

    # 读取CSV文件的内容
    with open('diabetes_012_health_indicators_BRFSS2015.csv', 'r') as file:
        reader = csv.reader(file)
        rows = list(reader)

    # 更改最后一行的第一个元素
    if rows:
        rows[-1][0] = y_pred

    # 将修改后的内容写回CSV文件
    with open('diabetes_012_health_indicators_BRFSS2015.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(rows)

    reverse_diabetes_prediction_mapping = {0: 'Low Risk', 1: 'Medium Risk', 2: 'High Risk'}
    risk = reverse_diabetes_prediction_mapping[y_pred]
    return risk


# 创建FastAPI实例
app = FastAPI()

# 连接数据库
DATABASE_URL = ""
engine = create_engine(DATABASE_URL)
# # SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
#
# with engine.connect() as conn:
#     query = text("SELECT VERSION()")
#     result = conn.execute(query).fetchone()
#     db_version = result[0]
#     print(f"Database version: {db_version}")
#     # return db_version

app = FastAPI()
app.mount("/frontend", StaticFiles(directory=r"C:\Users\czy\Desktop\final_project\frontend"), name="static")


@app.get("/")
async def index():

    response2 = Response('''

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" href="https://unpkg.com/element-ui/lib/theme-chalk/index.css" />
    <title>Insurance Management System</title>
    <style>
        #app {
            width: 1024px;
            margin: 0 auto;
        }

        .add-btn {
            margin-top: 20px;
            width: 100%;
        }

        .body {
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div id="app">
        <center>
            <h1>Insurance Management System</h1>
        </center>
        <div class="head">
            <a href=/frontend/ModuleOne.html><el-button type="primary" class="add-btn" plain>Module One: User Insurance Price Generation</el-button></a>
            <a href=/frontend/ModuleTwo.html><el-button type="primary" class="add-btn" plain>Module Two: Insurance Contract Information</el-button></a>
            <a href=/frontend/ModuleThree.html><el-button type="primary" class="add-btn" plain>Module Three: Company Registration Information</el-button></a>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
    <script src="https://unpkg.com/element-ui/lib/index.js"></script>
    <!-- 官网提供的 axios 在线地址 -->
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script>
        // var a='http://127.0.0.1:5555/s'
        new Vue({
            el: "#app",
            data: function () {
                return {};
            },

            methods: {},
        });
    </script>
</body>

</html>


    ''', media_type="text/html")

    return response2

from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class DiabetesRecord(Base):
    __tablename__ = 'diabetes'

    id = Column(Integer, primary_key=True)
    CustomerSSN = Column(Integer, nullable=False)
    DiabetesPrediction = Column(String(45))
    HighBP = Column(String(45))
    HighChol = Column(String(45))
    CholCheck = Column(String(45))
    BMI = Column(String(45))
    Smoker = Column(String(45))
    Stroke = Column(String(45))
    HeartDiseaseorAttack = Column(String(45))
    PhysActivity = Column(String(45))
    Fruits = Column(String(45))
    Veggies = Column(String(45))
    HvyAlcoholConsump = Column(String(45))
    AnyHealthcare = Column(String(45))
    NoDocbcCost = Column(String(45))
    GenHlth = Column(String(45))
    MentHlth = Column(String(45))
    PhysHlth = Column(String(45))
    DiffWalk = Column(String(45))
    Sex = Column(String(45))
    Education = Column(String(45))
    Income = Column(String(45))






from sqlalchemy.orm import sessionmaker

# 创建数据库会话
Session = sessionmaker(bind=engine)


@app.post("/api/diabetes/add")
async def add_diabetes_record(request: Request):
    data = await request.json()

    result = predict_risk(data)
    data['DiabetesPrediction'] = result
    data.pop("age")
    new_record = DiabetesRecord(**data)

    session = Session()


    try:
        session.add(new_record)
        session.commit()
        return {"status": "success", "message": "Record added successfully", "data": result}
    except Exception as e:
        session.rollback()
        raise Exception(f"Failed to add record: {str(e)}")
    finally:
        session.close()










#
# from sqlalchemy.orm import sessionmaker
#
# # 创建数据库会话
# Session = sessionmaker(bind=engine)
#
#
# @app.post("/api/diabetes/add")
# async def add_diabetes_record(request: Request):
#     data = await request.json()
#
#
#     new_record = DiabetesRecord(**data)
#
#     session = Session()
#     result = 2433
#
#     try:
#         session.add(new_record)
#         session.commit()
#         return {"status": "success", "message": "Record added successfully", "data": result}
#     except Exception as e:
#         session.rollback()
#         raise Exception(f"Failed to add record: {str(e)}")
#     finally:
#         session.close()



# 首先，定义Customer模型
class Customer(Base):
    __tablename__ = 'customer'

    CustomerSSN = Column(Integer, primary_key=True)
    CustomerFirstName = Column(String(255), nullable=False)
    CustomerMiddleName = Column(String(45))
    CustomerLastName = Column(String(45), nullable=False)
    CustomerAddress = Column(String(255))
    CustomerSalutation = Column(String(45))
    Gender = Column(String(1), nullable=False)
    CustomerDOB = Column(String(10), nullable=False)  # 此处我使用了String代替Date，确保前端传来的日期格式是'YYYY-MM-DD'
    CustomerMartial = Column(String(45))
    Age = Column(Integer)
    Height = Column(String(45))
    customercol = Column(String(45))

from datetime import datetime

# 然后，创建一个POST路由处理函数
@app.post("/api/customer/add")
async def add_customer(request: Request):
    data = await request.json()

    # 转换日期格式
    if 'CustomerDOB' in data:
        data['CustomerDOB'] = data['CustomerDOB'][0:10]


    new_customer = Customer(**data)

    session = Session()
    try:
        session.add(new_customer)
        session.commit()
        return {"status": "success", "message": "Customer added successfully"}
    except Exception as e:
        session.rollback()
        raise Exception(f"Failed to add customer: {str(e)}")
    finally:
        session.close()





from sqlalchemy import create_engine, Column, Integer, String, DECIMAL
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class PremiumRecord(Base):
    __tablename__ = 'premium'

    CustomerSSN = Column(Integer, primary_key=True)
    Diabetes = Column(String(45))
    BloodPressureProblems = Column(String(45))
    AnyTransplants = Column(String(45))
    AnyChronicDiseases = Column(String(45))
    Height = Column(String(45))
    Weight = Column(String(45))
    KnownAllergies = Column(String(45))
    HistoryOfCancerInFamily = Column(String(45))
    NumberOfMajorSurgeries = Column(Integer)
    DiabetesPrediction = Column(String(45))
    PremiumPrice = Column(DECIMAL(10,2))

from sqlalchemy.orm import sessionmaker

# Assuming the engine is already defined
Session = sessionmaker(bind=engine)

@app.post("/api/premium/add")
async def add_premium_record(request: Request):
    data = await request.json()
    price = predict_premium(data)
    data['PremiumPrice'] = price
    new_record = PremiumRecord(**data)


    session = Session()



    try:
        session.add(new_record)
        session.commit()
        return {"status": "success", "message": "Record added successfully", "data": price}
    except Exception as e:
        session.rollback()
        raise Exception(f"Failed to add record: {str(e)}")
    finally:
        session.close()




if __name__ == "__main__":
    uvicorn.run("server:app", host="127.0.0.1", port=5555)
















# def get_db_version():
#     with engine.connect() as conn:
#         query = text("SELECT VERSION()")
#         result = conn.execute(query).fetchone()
#         db_version = result[0]
#         print(f"Database version: {db_version}")
#         return db_version
#
# @app.get("/db_version")
# def db_version():
#     return {"version": get_db_version()}










# from fastapi import FastAPI, HTTPException
# from sqlalchemy import create_engine, Column, Integer, String, ForeignKey
# from sqlalchemy.orm import sessionmaker, relationship
# from sqlalchemy.ext.declarative import declarative_base
#
# # 创建FastAPI实例
# app = FastAPI()
#
# # 连接数据库
# DATABASE_URL = ""
# engine = create_engine(DATABASE_URL)
# SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
#
#
# with engine.connect() as conn:
#     query = text("SELECT VERSION()")
#     result = conn.execute(query).fetchone()
#     db_version = result[0]
#     print(f"Database version: {db_version}")





# print(1)
#
# # 声明基类
# Base = declarative_base()
#
# # 定义模型
# class Author(Base):
#     __tablename__ = "authors"
#
#     id = Column(Integer, primary_key=True, index=True)
#     name = Column(String, index=True)
#     bio = Column(String)
#
#     posts = relationship("Post", back_populates="author")
#
# class Post(Base):
#     __tablename__ = "posts"
#
#     id = Column(Integer, primary_key=True, index=True)
#     title = Column(String, index=True)
#     content = Column(String)
#     author_id = Column(Integer, ForeignKey("authors.id"))
#
#     author = relationship("Author", back_populates="posts")
#
# # 创建数据库表
# Base.metadata.create_all(bind=engine)
#
# # 路由定义
# @app.post("/authors/")
# def create_author(author: Author):
#     db = SessionLocal()
#     db.add(author)
#     db.commit()
#     db.refresh(author)
#     return author
#
# @app.post("/posts/")
# def create_post(post: Post):
#     db = SessionLocal()
#     db.add(post)
#     db.commit()
#     db.refresh(post)
#     return post
#
# @app.get("/authors/{author_id}")
# def get_author(author_id: int):
#     db = SessionLocal()
#     author = db.query(Author).filter(Author.id == author_id).first()
#     if author is None:
#         raise HTTPException(status_code=404, detail="Author not found")
#     return author
#
# @app.get("/posts/{post_id}")
# def get_post(post_id: int):
#     db = SessionLocal()
#     post = db.query(Post).filter(Post.id == post_id).first()
#     if post is None:
#         raise HTTPException(status_code=404, detail="Post not found")
#     return post

