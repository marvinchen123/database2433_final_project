# 导入必要的库
import pandas as pd
import csv
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import QuantileTransformer
from sklearn.preprocessing import StandardScaler,MinMaxScaler
from sklearn.preprocessing import LabelEncoder
from imblearn.over_sampling import RandomOverSampler
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import ConfusionMatrixDisplay
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score,classification_report,
                            ConfusionMatrixDisplay,precision_score,recall_score,
                            f1_score,roc_auc_score,roc_curve,balanced_accuracy_score,
                            confusion_matrix)

def transform_income(income):
    income = int(income)
    if income < 50000:
        return 1
    elif 50000 <= income < 100000:
        return 2
    elif 100000 <= income < 150000:
        return 3
    else:
        return 4


def transform_data(data):
    mapping = {
        'DiabetesPrediction': {'Low Risk': 0, 'Medium Risk': 1, 'High Risk': 2},
        'HighBP': {'No': 0, 'Yes': 1},
        'HighChol': {'No': 0, 'Yes': 1},
        'CholCheck': {'No': 0, 'Yes': 1},
        'Smoker': {'No': 0, 'Yes': 1},
        'Stroke': {'No': 0, 'Yes': 1},
        'HeartDiseaseorAttack': {'No': 0, 'Yes': 1},
        'PhysActivity': {'Regular': 0, 'Seldom': 1},
        'Fruits': {'Daily': 0, 'Rarely': 1},
        'Veggies': {'Daily': 0, 'Rarely': 1},
        'HvyAlcoholConsump': {'No': 0, 'Yes': 1},
        'AnyHealthcare': {'No': 0, 'Yes': 1},
        'NoDocbcCost': {'No': 0, 'Yes': 1},
        'GenHlth': {'Poor': 1, 'Average': 3, 'Good': 5},
        'MentHlth': {'Poor': 1, 'Average': 3, 'Good': 5},
        'PhysHlth': {'Poor': 1, 'Average': 3, 'Good': 5},
        'DiffWalk': {'No': 0, 'Yes': 1},
        'Sex': {'Male': 0, 'Female': 1},
        'Education': {'High School': 2, 'Bachelor': 3, 'Master': 4, 'PhD': 5},
        # 'Income': {'<40000': 1, '40000-80000': 2, '80000-120000': 3, '>120000': 4}
    }



    transformed_data = {}
    for key, value in data.items():
        if key in mapping:
            transformed_data[key] = mapping[key].get(value, value)
        elif key == 'Income':
            transformed_data[key] = transform_income(value)
        else:
            transformed_data[key] = value

    return transformed_data

age = 10

data = {'CustomerSSN': '444444444', 'DiabetesPrediction': 'Low Risk', 'HighBP': 'No', 'HighChol': 'No',
        'CholCheck': 'Yes', 'BMI': '23', 'Smoker': 'No', 'Stroke': 'No', 'HeartDiseaseorAttack': 'No',
        'PhysActivity': 'Regular', 'Fruits': 'Daily', 'Veggies': 'Daily', 'HvyAlcoholConsump': 'No',
        'AnyHealthcare': 'Yes', 'NoDocbcCost': 'No', 'GenHlth': 'Good', 'MentHlth': 'Good', 'PhysHlth': 'Good',
        'DiffWalk': 'No', 'Sex': 'Male', 'Education': "Master", 'Income': '120000'}

data['age'] = age
transformed_data = transform_data(data)

ordered_keys = ['DiabetesPrediction', 'HighBP', 'HighChol', 'CholCheck', 'BMI', 'Smoker', 'Stroke', 'HeartDiseaseorAttack', 'PhysActivity', 'Fruits', 'Veggies', 'HvyAlcoholConsump', 'AnyHealthcare', 'NoDocbcCost', 'GenHlth', 'MentHlth', 'PhysHlth', 'DiffWalk', 'Sex', 'age','Education', 'Income']
data_list = [transformed_data[key] for key in ordered_keys]

# with open('diabetes_012_health_indicators_BRFSS2015.csv', 'a', newline='') as csvfile:
#     writer = csv.writer(csvfile)
#     writer.writerow(data_list)


# 读取数据
df = pd.read_csv('diabetes_012_health_indicators_BRFSS2015.csv')

# 更改某列名称
df.rename(columns={'Diabetes_012':'Diabetes_binary'}, inplace=True)

# 创建新的特征：在过去30天内没有生病并且感觉非常好或者很好的人
df['PerfectHlth'] = (df['PhysHlth']==0.0) & (df['GenHlth']<3.0)
df['PerfectHlth'] = df['PerfectHlth'].astype(int)

# 创建新的特征：没有心脏疾病或高血压的人
df['NoHrtIssue'] = (df['HighBP']==0.0) & (df['HighChol']==0.0) & (df['HeartDiseaseorAttack']==0.0)
df['NoHrtIssue'] = df['NoHrtIssue'].astype(int)

# 创建新的特征：健康状况不太好的人和健康状况好于普通的人
df['hlthNotGood'] = df['GenHlth'] > 3
df['HlthAboveGood'] = df['GenHlth'] < 3
df['hlthNotGood'] = df['hlthNotGood'].astype(int)
df['HlthAboveGood'] = df['HlthAboveGood'].astype(int)

# 创建新的特征：有高血压和心脏疾病的人，以及年纪大且收入低的人
df['hbp&HA'] = (df['HeartDiseaseorAttack'] == 1.0) & (df['HighBP'] == 1.0)
df['hbp&HA'] = df['hbp&HA'].astype(int)
df['older&poor'] = (df['Age'] > 5.0) & (df['Income'] < 5)
df['older&poor'] = df['older&poor'].astype(int)

# 根据相关性删除不相关的列
df2 = df.drop(['Fruits', 'Veggies', 'AnyHealthcare', 'NoDocbcCost', 'Income',
              'Education', 'CholCheck'],axis=1)
df3 = df2.copy()

# 使用标准化方法标准化部分特征
sc =StandardScaler()
df3[['BMI']] = sc.fit_transform(df3[['BMI']])
df3[['Age']] = sc.fit_transform(df3[['Age']])
df3[['PhysHlth']] = sc.fit_transform(df3[['PhysHlth']])
df3[['MentHlth']] = sc.fit_transform(df3[['MentHlth']])

# 使用QuantileTransformer进一步转换特征
QT=QuantileTransformer(n_quantiles=500,output_distribution='normal')
df3[['BMI']] = QT.fit_transform(df3[['BMI']])
df3[['Age']] = QT.fit_transform(df3[['Age']])
df3[['PhysHlth']] = QT.fit_transform(df3[['PhysHlth']])
df3[['MentHlth']] = QT.fit_transform(df3[['MentHlth']])

# 定义特征和目标变量
X = df3.drop('Diabetes_binary', axis =1)
y = df3['Diabetes_binary']

predict_X = X[-1:]
X = X[:-1]
y = y[:-1]

# 使用过采样方法处理不平衡数据
OverS=RandomOverSampler(random_state=99, sampling_strategy='not majority')
X_over,y_over=OverS.fit_resample(X,y)

# 数据切分为训练集和测试集
X_over_train,X_over_test,y_over_train,y_over_test=train_test_split(X_over,y_over,test_size=0.2,random_state=99)



# 使用最佳参数训练一个新的随机森林模型
best_rfc = RandomForestClassifier(n_estimators=300, max_depth=20)
best_rfc.fit(X_over_train, y_over_train)

# 对测试集进行预测并计算各种评估指标
y_pred = int(best_rfc.predict(predict_X))


# 读取CSV文件的内容
with open('diabetes_012_health_indicators_BRFSS2015.csv', 'r') as file:
    reader = csv.reader(file)
    rows = list(reader)

# 更改最后一行的第一个元素
if rows:
    rows[-1][0] = y_pred

# 将修改后的内容写回CSV文件
with open('diabetes_012_health_indicators_BRFSS2015.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(rows)


reverse_diabetes_prediction_mapping = {0: 'Low Risk', 1: 'Medium Risk', 2: 'High Risk'}
risk = reverse_diabetes_prediction_mapping[y_pred]

print(risk)















import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import QuantileTransformer
from sklearn.preprocessing import StandardScaler,MinMaxScaler
from sklearn.preprocessing import LabelEncoder
from imblearn.over_sampling import RandomOverSampler
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import ConfusionMatrixDisplay
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,classification_report,ConfusionMatrixDisplay,precision_score,recall_score, f1_score,roc_auc_score,roc_curve,balanced_accuracy_score,confusion_matrix

#
# df = pd.read_csv('diabetes_012_health_indicators_BRFSS2015.csv')
#
# df.rename(columns={'Diabetes_012':'Diabetes_binary'}, inplace=True)
# # df.info()
#
#
# # HASN'T FALLEN SICK IN THE LAST 30 DAYS AND FEELS EXCELLENT OR VERY GOOD
# df['PerfectHlth'] = (df['PhysHlth']==0.0) & (df['GenHlth']<3.0)
# df['PerfectHlth'] = df['PerfectHlth'].astype(int)
#
#
# # No single issue with heart disease or BP
# df['NoHrtIssue'] = (df['HighBP']==0.0) & (df['HighChol']==0.0) & (df['HeartDiseaseorAttack']==0.0)
# df['NoHrtIssue'] = df['NoHrtIssue'].astype(int)
#
#
# # Diabetics would most likely feel unwell and in a slightly poorer state of health
# df['hlthNotGood'] = df['GenHlth'] > 3
# df['HlthAboveGood'] = df['GenHlth'] < 3
# df['hlthNotGood'] = df['hlthNotGood'].astype(int)
# df['HlthAboveGood'] = df['HlthAboveGood'].astype(int)
#
#
# # people with high blood pressure and heart disease/illness
# df['hbp&HA'] = (df['HeartDiseaseorAttack'] == 1.0) & (df['HighBP'] == 1.0)
# df['hbp&HA'] = df['hbp&HA'].astype(int)
# df['older&poor'] = (df['Age'] > 5.0) & (df['Income'] < 5)
# df['older&poor'] = df['older&poor'].astype(int)
#
# # drop irrelevant columns based on correlation
# df2 = df.drop(['Fruits', 'Veggies', 'AnyHealthcare', 'NoDocbcCost', 'Income',
#               'Education', 'CholCheck'],axis=1)
# df3 = df2.copy()
#
# sc =StandardScaler()
#
# df3[['BMI']] = sc.fit_transform(df3[['BMI']])
# df3[['Age']] = sc.fit_transform(df3[['Age']])
# df3[['PhysHlth']] = sc.fit_transform(df3[['PhysHlth']])
# df3[['MentHlth']] = sc.fit_transform(df3[['MentHlth']])
#
#
# QT=QuantileTransformer(n_quantiles=500,output_distribution='normal')
#
# df3[['BMI']] = QT.fit_transform(df3[['BMI']])
# df3[['Age']] = QT.fit_transform(df3[['Age']])
# df3[['PhysHlth']] = QT.fit_transform(df3[['PhysHlth']])
# df3[['MentHlth']] = QT.fit_transform(df3[['MentHlth']])
#
#
# X = df3.drop('Diabetes_binary', axis =1)
# y = df3['Diabetes_binary']
# OverS=RandomOverSampler(random_state=99, sampling_strategy='not majority')
# X_over,y_over=OverS.fit_resample(X,y)
# X_over_train,X_over_test,y_over_train,y_over_test=train_test_split(X_over,y_over,test_size=0.2,random_state=99)
#
#
# from sklearn.ensemble import RandomForestClassifier
# rfc = RandomForestClassifier()
#
# param_grid = {
#     'n_estimators': [50,  300],
#     'max_depth': [5,  20]
# }
#
#
# RF_grid_search_ = GridSearchCV(rfc, param_grid=param_grid, cv=3, n_jobs=-1,verbose=3)
# RF_grid_search_.fit(X_over_train,y_over_train)
#
#
# from sklearn.ensemble import RandomForestClassifier
# rfc = RandomForestClassifier()
#
# param_grid = {
#     'n_estimators': [50,  300],
#     'max_depth': [5,  20]
# }
#
#
# RF_grid_search_ = GridSearchCV(rfc, param_grid=param_grid, cv=3, n_jobs=-1,verbose=3)
# RF_grid_search_.fit(X_over_train,y_over_train)
#
#
# # Get the best parameters from the grid search
# best_params = RF_grid_search_.best_params_
# print("Best parameters found: ", best_params)
#
# # Use the best parameters to train a new RandomForestClassifier
# best_rfc = RandomForestClassifier(n_estimators=best_params['n_estimators'], max_depth=best_params['max_depth'])
# best_rfc.fit(X_over_train, y_over_train)
#
# from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, balanced_accuracy_score, roc_auc_score
# import pandas as pd
#
# # Predict on the test set
# y_pred = best_rfc.predict(X_over_test)
#
# # Calculate metrics
# accuracy = accuracy_score(y_over_test, y_pred)
# f1 = f1_score(y_over_test, y_pred, average='weighted')
# precision = precision_score(y_over_test, y_pred, average='weighted')
# recall = recall_score(y_over_test, y_pred, average='weighted')
# balanced_accuracy = balanced_accuracy_score(y_over_test, y_pred)
#
#
#
#
# # Create a DataFrame to display the results
# metrics_data = {
#     'Metric': ['Accuracy', 'F1 Score', 'Precision', 'Recall', 'Balanced Accuracy'],
#     'Value': [accuracy, f1, precision, recall, balanced_accuracy]
# }
#
# df_metrics = pd.DataFrame(metrics_data)
#
# print(df_metrics)
#
