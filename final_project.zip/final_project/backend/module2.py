import os
import openai

openai.api_key = ""


def get_sql_module2(user_request):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {
                "role": "system",
                "content": "Given the following SQL tables, your job is to write CRUD given a user’s request. Only output pure SQL statements each time; no other hints allowed. \n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`contract` (\n  `ContractID` INT NOT NULL,\n  `CustomerSSN` INT NOT NULL,\n  `ContractDetails` VARCHAR(255) NULL DEFAULT NULL,\n  PRIMARY KEY (`ContractID`),\n  INDEX `CustomerID` (`CustomerSSN` ASC) VISIBLE,\n  CONSTRAINT `contract_ibfk_1`\n    FOREIGN KEY (`CustomerSSN`)\n    REFERENCES `dmsproject`.`customer` (`CustomerSSN`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`contractbenefit` (\n  `ContractBenefitID` INT NOT NULL,\n  `ContractID` INT NULL DEFAULT NULL,\n  `BenefitDetails` VARCHAR(255) NULL DEFAULT NULL,\n  `ContractPremiumID` INT NULL DEFAULT NULL,\n  PRIMARY KEY (`ContractBenefitID`),\n  INDEX `ContractID` (`ContractID` ASC) VISIBLE,\n  CONSTRAINT `contractbenefit_ibfk_1`\n    FOREIGN KEY (`ContractID`)\n    REFERENCES `dmsproject`.`contract` (`ContractID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`customeraccountmember` (\n  `CustomerSSN` INT NOT NULL,\n  `AccountMemberID` INT NOT NULL,\n  `AccountStartDate` DATE NULL DEFAULT NULL,\n  `AccountEndDate` DATE NULL DEFAULT NULL,\n  `Comapany` VARCHAR(45) NULL DEFAULT NULL,\n  PRIMARY KEY (`CustomerSSN`, `AccountMemberID`),\n  INDEX `AccountMemberID` (`AccountMemberID` ASC) VISIBLE,\n  CONSTRAINT `customeraccountmember_ibfk_1`\n    FOREIGN KEY (`CustomerSSN`)\n    REFERENCES `dmsproject`.`customer` (`CustomerSSN`),\n  CONSTRAINT `customeraccountmember_ibfk_2`\n    FOREIGN KEY (`AccountMemberID`)\n    REFERENCES `dmsproject`.`accountmember` (`AccountMemberID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`customerassociate` (\n  `CustomerSSN` INT NOT NULL,\n  `AssociateSSN` INT NOT NULL,\n  `AssociateRole` VARCHAR(255) NULL DEFAULT NULL,\n  `Service_StartDate` DATE NULL DEFAULT NULL,\n  PRIMARY KEY (`CustomerSSN`, `AssociateSSN`),\n  INDEX `AssociateSSN` (`AssociateSSN` ASC) VISIBLE,\n  CONSTRAINT `customerassociate_ibfk_1`\n    FOREIGN KEY (`CustomerSSN`)\n    REFERENCES `dmsproject`.`customer` (`CustomerSSN`),\n  CONSTRAINT `customerassociate_ibfk_2`\n    FOREIGN KEY (`AssociateSSN`)\n    REFERENCES `dmsproject`.`associate` (`AssociateSSN`))\n"
            },
            {
                "role": "user",
                "content": user_request
            },

        ],
        temperature=0,
        max_tokens=1024,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0
    )

    return response.choices[0].message.content


user_request = "Contract Benefit:\n•\tContractID: 7001\n•\tContractBeniftID: 7001-222\n•\tContractDetails:Preventative Care\n•\tContractBeniftID: 7001-223\n•\tContractDetails: Dental\n\n将上面的数据插入到Managercontract这个表里"

sql_sentence = get_sql_module2(user_request)
print(sql_sentence)



















# import os
# import openai
#
# openai.api_key = os.getenv("OPENAI_API_KEY")
#
# response = openai.ChatCompletion.create(
#   model="gpt-3.5-turbo",
#   messages=[
#     {
#       "role": "system",
#       "content": "Given the following SQL tables, your job is to write CRUD given a user’s request. Only output pure SQL statements each time; no other hints allowed. \n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`contract` (\n  `ContractID` INT NOT NULL,\n  `CustomerSSN` INT NOT NULL,\n  `ContractDetails` VARCHAR(255) NULL DEFAULT NULL,\n  PRIMARY KEY (`ContractID`),\n  INDEX `CustomerID` (`CustomerSSN` ASC) VISIBLE,\n  CONSTRAINT `contract_ibfk_1`\n    FOREIGN KEY (`CustomerSSN`)\n    REFERENCES `dmsproject`.`customer` (`CustomerSSN`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`contractbenefit` (\n  `ContractBenefitID` INT NOT NULL,\n  `ContractID` INT NULL DEFAULT NULL,\n  `BenefitDetails` VARCHAR(255) NULL DEFAULT NULL,\n  `ContractPremiumID` INT NULL DEFAULT NULL,\n  PRIMARY KEY (`ContractBenefitID`),\n  INDEX `ContractID` (`ContractID` ASC) VISIBLE,\n  CONSTRAINT `contractbenefit_ibfk_1`\n    FOREIGN KEY (`ContractID`)\n    REFERENCES `dmsproject`.`contract` (`ContractID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`customeraccountmember` (\n  `CustomerSSN` INT NOT NULL,\n  `AccountMemberID` INT NOT NULL,\n  `AccountStartDate` DATE NULL DEFAULT NULL,\n  `AccountEndDate` DATE NULL DEFAULT NULL,\n  `Comapany` VARCHAR(45) NULL DEFAULT NULL,\n  PRIMARY KEY (`CustomerSSN`, `AccountMemberID`),\n  INDEX `AccountMemberID` (`AccountMemberID` ASC) VISIBLE,\n  CONSTRAINT `customeraccountmember_ibfk_1`\n    FOREIGN KEY (`CustomerSSN`)\n    REFERENCES `dmsproject`.`customer` (`CustomerSSN`),\n  CONSTRAINT `customeraccountmember_ibfk_2`\n    FOREIGN KEY (`AccountMemberID`)\n    REFERENCES `dmsproject`.`accountmember` (`AccountMemberID`))\n\nCREATE TABLE IF NOT EXISTS `dmsproject`.`customerassociate` (\n  `CustomerSSN` INT NOT NULL,\n  `AssociateSSN` INT NOT NULL,\n  `AssociateRole` VARCHAR(255) NULL DEFAULT NULL,\n  `Service_StartDate` DATE NULL DEFAULT NULL,\n  PRIMARY KEY (`CustomerSSN`, `AssociateSSN`),\n  INDEX `AssociateSSN` (`AssociateSSN` ASC) VISIBLE,\n  CONSTRAINT `customerassociate_ibfk_1`\n    FOREIGN KEY (`CustomerSSN`)\n    REFERENCES `dmsproject`.`customer` (`CustomerSSN`),\n  CONSTRAINT `customerassociate_ibfk_2`\n    FOREIGN KEY (`AssociateSSN`)\n    REFERENCES `dmsproject`.`associate` (`AssociateSSN`))\n"
#     },
#     {
#       "role": "user",
#       "content": "Contract Benefit:\n•\tContractID: 7001\n•\tContractBeniftID: 7001-222\n•\tContractDetails:Preventative Care\n•\tContractBeniftID: 7001-223\n•\tContractDetails: Dental\n\n将上面的数据插入到Managercontract这个表里"
#     },
#     {
#       "role": "assistant",
#       "content": "INSERT INTO `dmsproject`.`contractbenefit` (`ContractBenefitID`, `ContractID`, `BenefitDetails`) \nVALUES (7001-222, 7001, 'Preventative Care'), (7001-223, 7001, 'Dental');"
#     },
#     {
#       "role": "user",
#       "content": "Contract Information:\n•\tCustomerSSN: 123456789\n•\tContractID: 7001\n•\tContractDetails: Comprehensive Health Insurance Coverage for Apple Employees"
#     },
#     {
#       "role": "assistant",
#       "content": "INSERT INTO `dmsproject`.`contract` (`ContractID`, `CustomerSSN`, `ContractDetails`) \nVALUES (7001, 123456789, 'Comprehensive Health Insurance Coverage for Apple Employees');"
#     }
#   ],
#   temperature=0,
#   max_tokens=1024,
#   top_p=1,
#   frequency_penalty=0,
#   presence_penalty=0
# )

